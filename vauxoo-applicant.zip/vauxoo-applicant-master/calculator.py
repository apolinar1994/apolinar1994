"""
Your module documentation here
"""


class CalculatorClass(object):
    """
    Your class documentation here
    """

    def sum(self, num_list):
        """
        Your method documentation here
        """
        # your sum code here
        return "not implement yet"  # Remove this dummy line
